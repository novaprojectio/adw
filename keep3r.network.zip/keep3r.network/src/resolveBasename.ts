"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var is_ipfs_1 = __importDefault(require("is-ipfs"));
var resolveBasename = function (path) {
    var segments = path.split('/');
    var second = segments[1], third = segments[2];
    if (second === 'ipfs' && is_ipfs_1.default.cid(third)) {
        return "/ipfs/" + third + "/";
    }
    if (second === 'ipns') {
        return "/ipns/" + third + "/";
    }
    return '/';
};
exports.default = resolveBasename;
//# sourceMappingURL=resolveBasename.js.map