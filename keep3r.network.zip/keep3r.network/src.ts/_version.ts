export const version = "transactions/5.0.6";
//# sourceMappingURL=_version.js.map